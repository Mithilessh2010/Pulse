"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  Bell,
  BookOpen,
  Bot,
  BriefcaseBusiness,
  CalendarDays,
  CheckCircle2,
  ClipboardCheck,
  Command,
  FileText,
  FolderKanban,
  Inbox,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Menu,
  MessageSquare,
  Moon,
  Plus,
  ReceiptText,
  Search,
  Settings,
  ShieldCheck,
  Sun,
  Upload,
  Users,
  Wand2,
  X,
} from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from "react";
import { PulseLogo } from "@/components/PulseLogo";
import { askPulseResponses } from "@/lib/mockData";
import { usePulseStore } from "@/stores/usePulseStore";

const navGroups = [
  {
    label: "Operate",
    items: [
      { label: "Command Center", href: "/app", Icon: LayoutDashboard },
      { label: "Autopilot", href: "/app/autopilot", Icon: Wand2 },
      { label: "Inbox", href: "/app/inbox", Icon: Inbox },
      { label: "Ask Pulse", href: "/app/ask", Icon: Command },
    ],
  },
  {
    label: "Work",
    items: [
      { label: "Projects", href: "/app/projects", Icon: FolderKanban },
      { label: "Tasks", href: "/app/tasks", Icon: ListChecks },
      { label: "Approvals", href: "/app/approvals", Icon: ClipboardCheck },
      { label: "Expenses", href: "/app/expenses", Icon: ReceiptText },
    ],
  },
  {
    label: "Organization",
    items: [
      { label: "Teams", href: "/app/teams", Icon: BriefcaseBusiness },
      { label: "People", href: "/app/team", Icon: Users },
      { label: "Chat", href: "/app/chat", Icon: MessageSquare },
      { label: "Meetings", href: "/app/meetings", Icon: CalendarDays },
    ],
  },
  {
    label: "Intelligence",
    items: [
      { label: "Reports", href: "/app/reports", Icon: Activity },
      { label: "Decisions", href: "/app/decisions", Icon: ShieldCheck },
      { label: "Playbooks", href: "/app/playbooks", Icon: BookOpen },
      { label: "Import Data", href: "/app/import", Icon: Upload },
    ],
  },
  { label: "Admin", items: [{ label: "Settings", href: "/app/settings", Icon: Settings }] },
];

const allNavItems = navGroups.flatMap((group) => group.items);

const pageMeta: Record<string, { title: string; subtitle: string }> = {
  "/app": { title: "Command Center", subtitle: "Live overview of work, people, approvals, spend, and risk" },
  "/app/autopilot": { title: "Pulse Autopilot", subtitle: "Turn messy manager instructions into organized actions" },
  "/app/inbox": { title: "Manager Inbox", subtitle: "Everything needing review in one calm queue" },
  "/app/chat": { title: "Work Rooms", subtitle: "Team chat connected to projects, approvals, and decisions" },
  "/app/meetings": { title: "Meeting Hub", subtitle: "Fewer, better meetings with clear agendas and follow-ups" },
  "/app/teams": { title: "Teams", subtitle: "Team health, ownership, workload, and focus areas" },
  "/app/team": { title: "People", subtitle: "Support needs, capacity, availability, and delivery confidence" },
  "/app/projects": { title: "Projects", subtitle: "Track delivery, owners, budgets, and pacing" },
  "/app/tasks": { title: "Tasks", subtitle: "Manage due dates, proof, blockers, and review states" },
  "/app/approvals": { title: "Approvals", subtitle: "Review proof, expenses, and client updates in one queue" },
  "/app/expenses": { title: "Expenses", subtitle: "Monitor spend, budgets, and expense approvals" },
  "/app/ask": { title: "Ask Pulse", subtitle: "Query workspace context without digging through tabs" },
  "/app/reports": { title: "Reports", subtitle: "Generate summaries, exports, and leadership updates" },
  "/app/decisions": { title: "Decision Log", subtitle: "Keep important decisions out of scattered chat history" },
  "/app/playbooks": { title: "Playbooks", subtitle: "Reusable operating systems for repeated team workflows" },
  "/app/import": { title: "Import Data", subtitle: "Paste messy updates and let Pulse structure the work" },
  "/app/onboarding": { title: "Onboarding", subtitle: "Set up teams, projects, members, and themes" },
  "/app/settings": { title: "Settings", subtitle: "Enterprise controls, roles, integrations, AI, and theme" },
  "/app/dev/qa": { title: "Pulse QA", subtitle: "Internal stabilization checklist and route audit notes" },
};

const themes = [
  { id: "midnight", name: "Midnight Pulse", bg: "#07090F", panel: "#0A0F1C", text: "#F0F2F8", accent: "#6D5DFB" },
  { id: "graphite", name: "Graphite", bg: "#080808", panel: "#111111", text: "#F5F5F5", accent: "#60A5FA" },
  { id: "aurora", name: "Aurora", bg: "#061211", panel: "#0B1B20", text: "#EFFDFB", accent: "#14B8A6" },
  { id: "light", name: "Light Executive", bg: "#F6F8FB", panel: "#FFFFFF", text: "#111827", accent: "#4F46E5" },
];

type ModalKind = "Create Project" | "Create Task" | "Invite Member" | "Create Team" | "Submit Expense" | "Generate Report";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const meta = pageMeta[pathname] ?? pageMeta["/app"];
  const [mobileOpen, setMobileOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [floatingOpen, setFloatingOpen] = useState(false);
  const [modalKind, setModalKind] = useState<ModalKind | null>(null);
  const themeId = usePulseStore((state) => state.selectedTheme);
  const setSelectedTheme = usePulseStore((state) => state.setSelectedTheme);
  const notifications = usePulseStore((state) => state.notifications);
  const enterprise = usePulseStore((state) => state.enterprise);
  const markNotificationRead = usePulseStore((state) => state.markNotificationRead);
  const markAllNotificationsRead = usePulseStore((state) => state.markAllNotificationsRead);
  const createProject = usePulseStore((state) => state.createProject);
  const createTask = usePulseStore((state) => state.createTask);
  const inviteMember = usePulseStore((state) => state.inviteMember);
  const createTeam = usePulseStore((state) => state.createTeam);
  const submitExpense = usePulseStore((state) => state.submitExpense);
  const generateReport = usePulseStore((state) => state.generateReport);
  const [command, setCommand] = useState("");
  const [paletteQuery, setPaletteQuery] = useState("");
  const [miniPrompt, setMiniPrompt] = useState("");
  const [miniAnswer, setMiniAnswer] = useState(askPulseResponses["What is at risk?"]);
  const theme = themes.find((item) => item.id === themeId) ?? themes[0];

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen(true);
      }
      if (event.key === "Escape") {
        setPaletteOpen(false);
        setNotificationOpen(false);
        setCreateOpen(false);
        setFloatingOpen(false);
        setModalKind(null);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const paletteItems = [
    ...allNavItems.map((item) => ({ label: `Go to ${item.label}`, action: () => router.push(item.href), Icon: item.Icon })),
    { label: "Create Project", action: () => setModalKind("Create Project"), Icon: Plus },
    { label: "Invite Member", action: () => setModalKind("Invite Member"), Icon: Users },
    { label: "Create Team", action: () => setModalKind("Create Team"), Icon: BriefcaseBusiness },
    { label: "Generate Report", action: () => setModalKind("Generate Report"), Icon: FileText },
    { label: "Toggle Theme", action: () => cycleTheme(), Icon: Moon },
    { label: "Ask Pulse quick question", action: () => router.push("/app/ask"), Icon: Command },
  ];

  const filteredPalette = paletteItems.filter((item) => item.label.toLowerCase().includes(paletteQuery.toLowerCase()));

  function cycleTheme() {
    const currentIndex = themes.findIndex((item) => item.id === themeId);
    setSelectedTheme(themes[(currentIndex + 1) % themes.length].id);
  }

  function logout() {
    window.localStorage.removeItem("pulse-demo-session");
    router.push("/");
  }

  function submitCommand(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const query = command.trim();
    router.push(query ? `/app/ask?q=${encodeURIComponent(query)}` : "/app/ask");
    setMobileOpen(false);
  }

  async function askMini(prompt = miniPrompt) {
    const clean = prompt.trim();
    if (!clean) return;
    setMiniPrompt(clean);
    setMiniAnswer("Reading workspace context...");
    try {
      const response = await fetch("/api/ask-pulse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: clean, mode: "floating" }),
      });
      const data = await response.json();
      setMiniAnswer(typeof data.answer === "string" ? data.answer : askPulseResponses["What is at risk?"]);
    } catch {
      setMiniAnswer(askPulseResponses[clean] ?? askPulseResponses["What is at risk?"]);
    }
  }

  function openCreate(kind: ModalKind) {
    setModalKind(kind);
    setCreateOpen(false);
  }

  function saveCreateDraft() {
    if (modalKind === "Create Project") createProject();
    if (modalKind === "Create Task") createTask({ title: "New workspace task" });
    if (modalKind === "Invite Member") inviteMember();
    if (modalKind === "Create Team") createTeam();
    if (modalKind === "Submit Expense") submitExpense();
    if (modalKind === "Generate Report") generateReport();
    setModalKind(null);
  }

  const SidebarHeader = (
    <div className="shrink-0 px-4 py-5">
      <a href="/" className="flex items-center gap-3">
        <PulseLogo />
        <div>
          <p className="text-[15px] font-semibold tracking-[-0.02em] text-[var(--pulse-text)]">Pulse</p>
          <p className="text-xs text-[#6B7A9F]">Enterprise operating system</p>
        </div>
      </a>
    </div>
  );

  const SidebarNav = (
    <nav className="min-h-0 flex-1 overflow-y-auto px-3 pb-6">
      <div className="space-y-5">
        {navGroups.map((group) => (
          <div key={group.label} className="space-y-2">
            <p className="px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#4D5E78]">{group.label}</p>
            <div className="space-y-1">
              {group.items.map(({ label, href, Icon }) => {
                const active = pathname === href;
                return (
                  <motion.a
                    key={href}
                    href={href}
                    onClick={() => setMobileOpen(false)}
                    whileHover={{ x: 3 }}
                    className={`flex h-9 w-full items-center gap-3 rounded-lg px-3 text-[13px] font-medium transition focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/50 ${
                      active ? "border border-[var(--pulse-accent)]/30 bg-white/[0.075] text-[var(--pulse-text)]" : "text-[#7F8BA6] hover:bg-white/[0.04] hover:text-[var(--pulse-text)]"
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{label}</span>
                  </motion.a>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </nav>
  );

  const SidebarFooter = (
    <div className="shrink-0 border-t border-white/[0.06] p-4">
      <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-4">
        <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-[#4D5E78]">Workspace</p>
        <p className="mt-2 text-sm font-semibold text-[var(--pulse-text)]">{enterprise.name}</p>
        <div className="mt-4 flex items-center gap-3 border-t border-white/10 pt-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[var(--pulse-accent)] text-sm font-semibold text-white">M</div>
          <div>
            <p className="text-sm font-medium text-[var(--pulse-text)]">{enterprise.owner}</p>
            <p className="text-xs text-[#6B7A9F]">Owner</p>
          </div>
        </div>
        <button onClick={logout} className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-[#9BA8C7] transition hover:text-[var(--pulse-text)] focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/50">
          <LogOut className="h-3.5 w-3.5" />
          Log out
        </button>
      </div>
    </div>
  );

  return (
    <main
      className="relative min-h-screen overflow-hidden text-[var(--pulse-text)] transition-colors duration-300"
      style={{
        "--pulse-bg": theme.bg,
        "--pulse-panel": theme.panel,
        "--pulse-text": theme.text,
        "--pulse-accent": theme.accent,
        background: theme.bg,
      } as CSSProperties}
    >
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse 52% 34% at 12% 8%, ${theme.accent}24, transparent 70%), radial-gradient(ellipse 42% 30% at 88% 16%, rgba(0,180,216,0.08), transparent 70%)` }} />
      <div className="relative z-10 flex">
        <aside className="hidden h-screen w-[280px] shrink-0 flex-col overflow-hidden border-r border-white/[0.06] bg-[var(--pulse-bg)]/90 backdrop-blur-xl lg:sticky lg:top-0 lg:flex">
          {SidebarHeader}
          {SidebarNav}
          {SidebarFooter}
        </aside>
        {mobileOpen ? (
          <div className="fixed inset-0 z-50 lg:hidden">
            <button aria-label="Close sidebar overlay" className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
            <motion.aside initial={{ x: -300 }} animate={{ x: 0 }} className="relative flex h-full w-[300px] flex-col overflow-hidden border-r border-white/10 bg-[var(--pulse-bg)]/96 backdrop-blur-xl">
              <button aria-label="Close sidebar" onClick={() => setMobileOpen(false)} className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-[#9BA8C7]">
                <X className="h-4 w-4" />
              </button>
              {SidebarHeader}
              {SidebarNav}
              {SidebarFooter}
            </motion.aside>
          </div>
        ) : null}
        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-[var(--pulse-bg)]/82 px-4 py-4 backdrop-blur-xl md:px-6">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
              <div>
                <p className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em]" style={{ color: theme.accent }}>
                  <button aria-label="Open sidebar" onClick={() => setMobileOpen(true)} className="mr-1 flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-[#9BA8C7] lg:hidden">
                    <Menu className="h-4 w-4" />
                  </button>
                  <Command className="h-3.5 w-3.5" />
                  Pulse
                  <span className="rounded-md border border-white/10 px-2 py-0.5 text-[10px] text-[#7F8BA6]">Cmd K</span>
                </p>
                <h1 className="text-2xl font-bold tracking-[-0.02em] md:text-3xl">{meta.title}</h1>
                <p className="mt-1 text-sm text-[#6B7A9F]">{meta.subtitle}</p>
              </div>
              <div className="flex flex-col gap-3 md:flex-row md:items-center">
                <form onSubmit={submitCommand} className="relative block md:w-[360px]">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#4D5E78]" />
                  <input value={command} onChange={(event) => setCommand(event.target.value)} placeholder="Ask Pulse or search workspace..." className="h-10 w-full rounded-lg border border-white/10 bg-white/[0.04] pl-9 pr-3 text-sm outline-none transition placeholder:text-[#4D5E78] focus:border-[var(--pulse-accent)]/70 focus:bg-white/[0.065]" />
                </form>
                <div className="relative flex items-center gap-2">
                  <button aria-label="Open notifications" onClick={() => setNotificationOpen((open) => !open)} className="relative flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-[#9BA8C7] transition hover:text-[var(--pulse-text)]">
                    <Bell className="h-4 w-4" />
                    {notifications.some((n) => n.unread) ? <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#00B4D8]" /> : null}
                  </button>
                  <button aria-label="Cycle theme" onClick={cycleTheme} className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-[#9BA8C7] transition hover:text-[var(--pulse-text)]">
                    {themeId === "light" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                  </button>
                  <div className="relative">
                    <button onClick={() => setCreateOpen((open) => !open)} className="inline-flex h-10 items-center gap-2 rounded-lg bg-[var(--pulse-accent)] px-4 text-[13px] font-semibold text-white">
                      <Plus className="h-4 w-4" />
                      Create
                    </button>
                    <AnimatePresence>
                      {createOpen ? (
                        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="absolute right-0 top-12 z-50 w-56 rounded-2xl border border-white/10 bg-[var(--pulse-panel)] p-2 shadow-2xl">
                          {(["Create Project", "Create Task", "Invite Member", "Create Team", "Submit Expense", "Generate Report"] as ModalKind[]).map((item) => (
                            <button key={item} onClick={() => openCreate(item)} className="block w-full rounded-xl px-3 py-2 text-left text-sm text-[#C8D0E8] hover:bg-white/[0.06] hover:text-[var(--pulse-text)]">{item}</button>
                          ))}
                        </motion.div>
                      ) : null}
                    </AnimatePresence>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/[0.06] text-sm font-semibold ring-1 ring-white/10">M</div>
                </div>
              </div>
            </div>
          </header>
          <div className="p-4 md:p-6">{children}</div>
        </div>
      </div>

      <AnimatePresence>
        {paletteOpen ? (
          <motion.div className="fixed inset-0 z-[80] flex items-start justify-center bg-black/55 px-4 pt-[12vh] backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div initial={{ opacity: 0, scale: 0.96, y: 12 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.96, y: 12 }} className="w-full max-w-2xl rounded-[24px] border border-white/10 bg-[var(--pulse-panel)]/96 p-3 shadow-2xl">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6B7A9F]" />
                <input autoFocus value={paletteQuery} onChange={(event) => setPaletteQuery(event.target.value)} placeholder="Search pages, create actions, ask Pulse..." className="h-12 w-full rounded-2xl border border-white/10 bg-white/[0.04] pl-11 pr-4 text-sm outline-none focus:border-[var(--pulse-accent)]/60" />
              </div>
              <div className="mt-3 max-h-[420px] overflow-y-auto">
                {filteredPalette.length ? filteredPalette.map(({ label, action, Icon }) => (
                  <button key={label} onClick={() => { action(); setPaletteOpen(false); }} className="flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left text-sm text-[#C8D0E8] hover:bg-white/[0.06] hover:text-[var(--pulse-text)]">
                    <Icon className="h-4 w-4" />
                    {label}
                  </button>
                )) : <div className="p-6 text-center text-sm text-[#6B7A9F]">No matching command.</div>}
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <AnimatePresence>
        {notificationOpen ? (
          <motion.aside initial={{ x: 420 }} animate={{ x: 0 }} exit={{ x: 420 }} className="fixed right-0 top-0 z-[70] h-full w-full max-w-[400px] border-l border-white/10 bg-[var(--pulse-panel)]/96 p-5 shadow-2xl backdrop-blur-xl">
            <div className="mb-5 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">Notifications</h2>
                <p className="text-sm text-[#6B7A9F]">Signals that need manager attention.</p>
              </div>
              <button aria-label="Close notifications" onClick={() => setNotificationOpen(false)} className="rounded-lg border border-white/10 p-2 text-[#9BA8C7]"><X className="h-4 w-4" /></button>
            </div>
            <button onClick={markAllNotificationsRead} className="mb-3 rounded-lg border border-white/10 px-3 py-2 text-xs text-[#C8D0E8]">Mark all read</button>
            <div className="space-y-2">
              {notifications.map((item) => (
                <div key={item.id} className="rounded-2xl border border-white/10 bg-white/[0.035] p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div><p className="text-sm font-semibold">{item.title}</p><p className="mt-1 text-xs leading-5 text-[#7F8BA6]">{item.description}</p></div>
                    {item.unread ? <span className="mt-1 h-2 w-2 rounded-full bg-[#00B4D8]" /> : null}
                  </div>
                  <div className="mt-3 flex items-center justify-between text-xs text-[#6B7A9F]"><span>{item.time}</span><button onClick={() => markNotificationRead(item.id)} className="text-[#C8D0E8]">{item.action}</button></div>
                </div>
              ))}
            </div>
          </motion.aside>
        ) : null}
      </AnimatePresence>

      <AnimatePresence>
        {modalKind ? (
          <motion.div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/55 px-4 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }} className="w-full max-w-lg rounded-[24px] border border-white/10 bg-[var(--pulse-panel)] p-5 shadow-2xl">
              <div className="mb-4 flex items-start justify-between gap-4">
                <div><h2 className="text-lg font-semibold">{modalKind}</h2><p className="mt-1 text-sm text-[#7F8BA6]">Create a workspace draft and review it before sharing with the team.</p></div>
                <button aria-label="Close modal" onClick={() => setModalKind(null)} className="rounded-lg border border-white/10 p-2 text-[#9BA8C7]"><X className="h-4 w-4" /></button>
              </div>
              <div className="space-y-3">
                <label className="block text-sm text-[#C8D0E8]">Name<input className="mt-2 h-10 w-full rounded-xl border border-white/10 bg-white/[0.04] px-3 outline-none focus:border-[var(--pulse-accent)]/60" placeholder={`${modalKind} name`} /></label>
                <label className="block text-sm text-[#C8D0E8]">Notes<textarea className="mt-2 min-h-[92px] w-full rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 outline-none focus:border-[var(--pulse-accent)]/60" placeholder="Add context..." /></label>
                <button onClick={saveCreateDraft} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[var(--pulse-accent)] px-4 py-3 text-sm font-semibold text-white"><CheckCircle2 className="h-4 w-4" />Save draft</button>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <div className="fixed bottom-5 right-5 z-40">
        <AnimatePresence>
          {floatingOpen ? (
            <motion.div initial={{ opacity: 0, y: 16, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.96 }} className="mb-3 w-[min(360px,calc(100vw-40px))] rounded-[22px] border border-white/10 bg-[var(--pulse-panel)]/96 p-4 shadow-2xl backdrop-blur-xl">
              <div className="mb-3 flex items-center justify-between"><p className="text-sm font-semibold">Ask Pulse</p><button onClick={() => setFloatingOpen(false)} className="text-[#9BA8C7]"><X className="h-4 w-4" /></button></div>
              <div className="flex flex-wrap gap-2">{["What needs attention?", "Who needs support?", "What is blocked?", "Write update"].map((chip) => <button key={chip} onClick={() => askMini(chip)} className="rounded-full border border-white/10 px-3 py-1.5 text-xs text-[#9BA8C7] hover:text-[var(--pulse-text)]">{chip}</button>)}</div>
              <form onSubmit={(event) => { event.preventDefault(); askMini(); }} className="mt-3 flex gap-2"><input value={miniPrompt} onChange={(event) => setMiniPrompt(event.target.value)} placeholder="Ask Pulse..." className="h-10 min-w-0 flex-1 rounded-xl border border-white/10 bg-white/[0.04] px-3 text-sm outline-none" /><button type="submit" className="rounded-xl bg-[var(--pulse-accent)] px-3 text-sm font-semibold text-white">Ask</button></form>
              <p className="mt-3 rounded-xl border border-white/10 bg-white/[0.035] p-3 text-xs leading-5 text-[#C8D0E8]">{miniAnswer}</p>
            </motion.div>
          ) : null}
        </AnimatePresence>
        <button onClick={() => setFloatingOpen((open) => !open)} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--pulse-accent)] text-white shadow-[0_18px_45px_rgba(0,0,0,0.3)]">
          <Bot className="h-5 w-5" />
        </button>
      </div>
    </main>
  );
}
